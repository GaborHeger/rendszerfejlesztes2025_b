<div class="menu">
    <div class="menu-left">
        <a href="index.php">Kezdőlap</a>
        <a href="menetrend.php">Menetrend keresés</a>
        <a href="jegyvasarlas.php">Jegyvásárlás</a>
    </div>
    <div class="menu-right">
        <a href="profil.php">Bejelentkezés/Regisztráció</a>
    </div>
</div>
