
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="menu.css">
    
</head>
<body>
    <div class="menu">
        <div class="menu-left">
            <a href="index.php">Kezdőlap</a>
            <a href="menetrend.php">Menetrend keresés</a>
            <a href="jegyvasarlas.php">Jegyvásárlás</a>
        </div>
        <div class="menu-right">
            <a href="profil.php">Bejelentkezés/Regisztráció</a>
        </div>
    </div>
</body>
</html>
