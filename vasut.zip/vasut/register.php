<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Regisztráció</title>
    <link rel="stylesheet" href="oldal_style.css">
    <link rel="stylesheet" href="menetrend.css">
    <link rel="stylesheet" href="register.css">
</head>
<body>
<?php include 'menu.php'; ?>
<?php
require_once 'db.php';

$hiba = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $password2 = $_POST["password2"];

    if($password !== $password2){
        $hiba = "A két jelszó nem egyezik!";
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO felhasznalo(nev, email, jelszo) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashed);
    
        if ($stmt->execute()) {
            header("Location: login.php?regok=1");
            exit();
        } else {
            $hiba = "Ez a felhasználónév vagy email már létezik!";
        }
    }
}
?>


<div class="page-container">

    <h1>Regisztráció</h1>

    <form action="" method="POST" class="search-form">

        <div class="input-group">
            <label>Felhasználónév</label>
            <input type="text" name="username" required>
        </div>
        <div class="input-group">
            <label>Email</label>
            <input type="email" name="email" required>
        </div>
        <div class="input-group">
            <label>Jelszó</label>
            <input type="password" name="password" required>
        </div>
        <div class="input-group">
            <label>Jelszó újra</label>
            <input type="password" name="password2" required>
        </div>

        <button type="submit" class="search-btn">Regisztráció</button>

        <?php if ($hiba): ?>
            <p style="color:#ff4a4a; font-weight:bold; margin-top:15px;"><?php echo $hiba; ?></p>
        <?php endif; ?>

    </form>

</div>
</body>
</html>