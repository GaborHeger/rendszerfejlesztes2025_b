<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Bejelentkezés</title>
    <link rel="stylesheet" href="oldal_style.css">
    <link rel="stylesheet" href="menetrend.css">
    <link rel="stylesheet" href="login.css">
</head>
<body>
<?php include 'menu.php'; ?>

<?php
require_once 'db.php';
session_start();

$hiba = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT felhasznalo_id, jelszo FROM felhasznalo WHERE nev=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($felhasznalo_id, $hashed_pw);
    $stmt->fetch();

    if ($stmt->num_rows > 0 && password_verify($password, $hashed_pw)) {
        $_SESSION["user_id"] = $felhasznalo_id;
        $_SESSION["username"] = $username;
        header("Location: profil.php");
        exit();
    } else {
        $hiba = "Hibás felhasználónév vagy jelszó!";
    }
}
?>

<div class="page-container">

    <h1>Bejelentkezés</h1>

    <?php if (isset($_GET["regok"])): ?>
        <p style="color:green; font-weight:bold;">Sikeres regisztráció! Jelentkezz be!</p>
    <?php endif; ?>

    <form action="" method="POST" class="search-form">

        <div class="input-group">
            <label>Felhasználónév</label>
            <input type="text" name="username" required>
        </div>

        <div class="input-group">
            <label>Jelszó</label>
            <input type="password" name="password" required>
        </div>

        <button type="submit" class="search-btn">Bejelentkezés</button>

        <?php if ($hiba): ?>
            <p style="color:#ff4a4a; font-weight:bold; margin-top:15px;"><?php echo $hiba; ?></p>
        <?php endif; ?>

    </form>

</div>
</body>
</html>