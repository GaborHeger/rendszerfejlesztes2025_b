<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Bejelentkezés / Regisztráció</title>
    <link rel="stylesheet" href="oldal_style.css">
    <link rel="stylesheet" href="menetrend.css"> 
    <link rel="stylesheet" href="profil.css">
</head>
<body>
<?php include 'menu.php'; ?>


<?php
include 'db.php';
session_start();

$hiba = "";
$siker = "";

/* ----------- Regisztráció ----------- */
if (isset($_POST["reg_username"])) {
    $username = $_POST["reg_username"];
    $email = $_POST["reg_email"];
    $password = password_hash($_POST["reg_password"], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users(username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $email, $password);

    if ($stmt->execute()) {
        $siker = "Sikeres regisztráció! Jelentkezz be!";
    } else {
        $hiba = "Ez a felhasználónév vagy email már létezik!";
    }
}

/* ----------- Bejelentkezés ----------- */
if (isset($_POST["log_username"])) {
    $username = $_POST["log_username"];
    $password = $_POST["log_password"];

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $hashed_pw);
    $stmt->fetch();

    if ($stmt->num_rows > 0 && password_verify($password, $hashed_pw)) {
        $_SESSION["user_id"] = $id;
        $_SESSION["username"] = $username;
        header("Location: index.php");
        exit();
    } else {
        $hiba = "Hibás felhasználónév vagy jelszó!";
    }
}
?>



<div class="page-container">

    <h1>Bejelentkezés / Regisztráció</h1>

    <?php if ($hiba): ?>
        <p style="color:#ff4a4a; font-weight:bold;"><?php echo $hiba; ?></p>
    <?php endif; ?>

    <?php if ($siker): ?>
        <p style="color:green; font-weight:bold;"><?php echo $siker; ?></p>
    <?php endif; ?>

    <h2>Bejelentkezés</h2>
    <form method="POST" class="search-form">
        <div class="input-group">
            <label>Felhasználónév</label>
            <input type="text" name="log_username" required>
        </div>
        <div class="input-group">
            <label>Jelszó</label>
            <input type="password" name="log_password" required>
        </div>
        <button type="submit" class="search-btn">Bejelentkezés</button>
    </form>

    <br><br>

    <h2>Regisztráció</h2>
    <form method="POST" class="search-form">
        <div class="input-group">
            <label>Felhasználónév</label>
            <input type="text" name="reg_username" required>
        </div>
        <div class="input-group">
            <label>Email</label>
            <input type="email" name="reg_email" required>
        </div>
        <div class="input-group">
            <label>Jelszó</label>
            <input type="password" name="reg_password" required>
        </div>
        <button type="submit" class="search-btn">Regisztráció</button>
    </form>

</div>

</body>
</html>
