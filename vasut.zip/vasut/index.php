<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vasút</title>
    <link rel="stylesheet" href="oldal_style.css">
    <link rel="stylesheet" href="index.css">
    <link rel="icon" type="image/jpeg" href="kepek/vonat.jpg">
</head>
<body>
    <?php include 'menu.php'; ?>
    <main class="welcome-container">
        <h1 class="welcome-text">Üdvözlünk a Vasútnál!</h1>
    </main>
    <div class="buisness"><h2>Az Expres Vasúttársaság évtizedek óta elkötelezetten dolgozik azon, hogy biztonságos, megbízható és kényelmes utazást biztosítson minden utasának.
         Hálózatunk nap mint nap összeköti a városokat, településeket és embereket – legyen szó munkába járásról, tanulásról vagy kikapcsolódásról.
         Célunk, hogy szolgáltatásainkkal nemcsak eljuttassuk utasainkat a céljukhoz, hanem kellemes és modern utazási élményt is nyújtsunk.
         Folyamatos fejlesztéseinkkel és elhivatott munkatársainkkal azon dolgozunk, hogy a vasúti közlekedés a jövőben is környezetbarát, korszerű és mindenki számára elérhető alternatíva maradjon.</h2>
    </div>

    <script>
        // Menü elrejtése lefelé görgetéskor
        let lastPos = 0;
        const menu = document.querySelector('.menu');

        window.addEventListener('scroll', () => {
            const current = window.pageYOffset;
            if (current > lastPos) {
                menu.classList.add('menu-hide');
            } else {
                menu.classList.remove('menu-hide');
            }
            lastPos = current;
        });
    </script>
</body>
</html>
