<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vasút</title>
    <link rel="stylesheet" href="oldal_style.css">
    <link rel="stylesheet" href="menetrend.css">
    <link rel="icon" type="image/jpeg" href="kepek/vonat.jpg">
</head>
<body>
    <?php include 'menu.php'; ?>
<div class="page-container">

    <div class="search-and-image">

        <div class="search-box">
            <h1>Menetrend kereső</h1>

            <form method="GET" class="search-form">
                <div class="input-group">
                    <label>Honnan:</label>
                    <input type="text" name="from" placeholder="Kiindulási állomás...">
                </div>

                <div class="input-group">
                    <label>Hová:</label>
                    <input type="text" name="to" placeholder="Célállomás...">
                </div>

                <div class="input-group">
                    <label>Dátum:</label>
                    <input type="date" name="date">
                </div>

                <button type="submit" class="search-btn">Keresés</button>
            </form>

            <div class="results-placeholder">
                Add meg a keresési feltételeket a találatok megjelenítéséhez.
            </div>
        </div>
    </div>

</div>
</body>
</html>
