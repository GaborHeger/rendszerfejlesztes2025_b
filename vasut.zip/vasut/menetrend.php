<?php 
require_once 'db.php';
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vasút – Menetrend</title>

    <link rel="stylesheet" href="oldal_style.css">
    <link rel="stylesheet" href="menetrend.css">
    <link rel="stylesheet" href="menu.css">
    <link rel="icon" type="image/jpeg" href="kepek/vonat.jpg">
</head>

<body>

<?php include 'menu.php'; ?>

<div class="page-container">

    <div class="search-and-image">

        <div class="search-box">
            <h1>Menetrend kereső</h1>

            <form method="GET" class="search-form">
                <div class="input-group">
                    <label>Honnan:</label>
                    <input type="text" name="from" placeholder="Kiindulási állomás..." required>
                </div>

                <div class="input-group">
                    <label>Hová:</label>
                    <input type="text" name="to" placeholder="Célállomás..." required>
                </div>

                <div class="input-group">
                    <label>Dátum:</label>
                    <input type="date" name="date" required>
                </div>

                <button type="submit" class="search-btn">Keresés</button>
            </form>


            <?php
            if(isset($_GET['from']) && isset($_GET['to']) && isset($_GET['date']))
            {
                $from = $_GET['from'];
                $to = $_GET['to'];
                $date = $_GET['date'];

                $like_from = "%$from%";
                $like_to = "%$to%";

                $stmt = $conn->prepare("
                    SELECT * FROM jarat
                    WHERE indulasi_allomas LIKE ?
                    AND erkezesi_allomas LIKE ?
                    AND DATE(indulasi_ido) = ?
                    ORDER BY indulasi_ido ASC
                ");

                $stmt->bind_param("sss", $like_from, $like_to, $date);
                $stmt->execute();
                $result = $stmt->get_result();

                echo '<div class="results-box">';
                echo "<h2>Találatok:</h2>";

                if ($result->num_rows === 0) {
                    echo "<p>Nincs találat a megadott feltételekkel.</p>";
                } else {
                    while ($row = $result->fetch_assoc()) {
                        echo "<div class='result-item'>";
                        echo "<p><strong>Járat:</strong> {$row['jarat_szam']}</p>";
                        echo "<p><strong>Indulás:</strong> {$row['indulasi_allomas']} – {$row['indulasi_ido']}</p>";
                        echo "<p><strong>Érkezés:</strong> {$row['erkezesi_allomas']} – {$row['erkezesi_ido']}</p>";
                        echo "</div>";
                    }
                }

                echo "</div>"; 
            }
            else
            {
                echo '<div class="results-placeholder">';
                echo "Add meg a keresési feltételeket a találatok megjelenítéséhez.";
                echo "</div>";
            }
            ?>

        </div>
    </div>

</div>

</body>
</html>
