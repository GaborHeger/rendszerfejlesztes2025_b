
<?php
include 'db.php';
session_start();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Jegyvásárlás</title>
    
    <link rel="stylesheet" href="oldal_style.css">
    <link rel="stylesheet" href="menetrend.css">
    
    <style>
        .ticket-container {
            max-width: 700px;
            margin: 40px auto;
            background: rgba(233, 244, 255, 0.95); 
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.15);
        }
        h1 {
            text-align: center;
            margin-bottom: 25px;
            color: #0f4a6d;
        }

        .input-group select {
            width: 100%;
            padding: 10px;
            border: 2px solid #0f4a6d; 
            border-radius: 6px; 
            font-size: 16px;
            box-sizing: border-box; 
            height: auto; 
        }

        .search-btn {
            background-color: #ffc400;
            color: black;
            font-weight: bold;
            width: 50%;
            width: auto !important; 
            display: block;
            margin: 20px auto 0 auto;
        }

        .search-btn:hover {
            background-color: #ffdd4d;
        }

        .results-box {
            background: #e9f4ff;
            padding: 20px;
            border-radius: 10px;
            margin-top: 25px;
            border-left: 4px solid #0f4a6d;
        }
    </style>
</head>
<body>

<?php include 'menu.php'; ?>

<div class="ticket-container">

    <h1>Jegyvásárlás</h1>

    <form method="POST" class="search-form">

        <div class="input-group">
            <label>Indulási állomás</label>
            <input type="text" name="indulas" placeholder="Pl. Budapest Keleti" required>
        </div>

        <div class="input-group">
            <label>Érkezési állomás</label>
            <input type="text" name="erkezes" placeholder="Pl. Debrecen" required>
        </div>

        <div class="input-group">
            <label>Indulás dátuma</label>
            <input type="date" name="datum" required>
        </div>

        <div class="input-group">
            <label>Indulás időpontja</label>
            <input type="time" name="ido" required>
        </div>

        <div class="input-group">
            <label>Utasok száma</label>
            <input type="number" name="utasok" min="1" value="1" required>
        </div>

        <div class="input-group">
            <label>Osztály</label>
            <select name="osztaly">
                <option value="2">2. osztály</option>
                <option value="1">1. osztály</option>
            </select>
        </div>

        <div class="input-group">
            <label>Jegytípus</label>
            <select name="jegytipus">
                <option value="normal">Normál</option>
                <option value="diak">Diák</option>
                <option value="nyugdijas">Nyugdíjas</option>
            </select>
        </div>

        <button type="submit" class="search-btn">Jegyek keresése</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $from = $_POST["indulas"];
        $to = $_POST["erkezes"];
        $date = $_POST["datum"];
        $time = $_POST["ido"];
        $utas = $_POST["utasok"];
        $osztaly = $_POST["osztaly"];
        $tipus = $_POST["jegytipus"];

        echo "<div class='results-box'>";
        echo "<h3>Talált jegyek:</h3>";
        echo "<p><strong>$from → $to</strong></p>";
        echo "<p>Dátum: $date $time</p>";
        echo "<p>Utasok: $utas fő</p>";
        echo "<p>Osztály: $osztaly.</p>";
        echo "<p>Jegytípus: " . ucfirst($tipus) . "</p>";
        echo "<p style='margin-top:15px; font-weight:bold;'>Jegyek lekérése sikeres (demo mód)!</p>";
        echo "</div>";
    }
    ?>

</div>

</body>
</html>