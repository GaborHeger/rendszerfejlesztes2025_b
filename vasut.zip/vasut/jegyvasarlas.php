<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vasút</title>
    <link rel="stylesheet" href="oldal_style.css">
    <link rel="stylesheet" href="jegyvasarlas.css">
    <link rel="icon" type="image/jpeg" href="kepek/vonat.jpg">
</head>
<body>
    <?php include 'menu.php'; ?>
</body>
</html>
