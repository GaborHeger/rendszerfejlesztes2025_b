<?php
session_start();
require_once 'db.php';

// Csak bejelentkezett felhasználó vásárolhat jegyet
if(!isset($_SESSION['user_id'])){
    header("Location: profil.php?login_required=1");
    exit();
}

$uzenet = "";

// Ha a menetrendből jöttünk
if(isset($_GET['jarat_id'])){
    $jarat_id = $_GET['jarat_id'];

    $stmt = $conn->prepare("SELECT * FROM jarat WHERE jarat_id = ?");
    $stmt->bind_param("i", $jarat_id);
    $stmt->execute();
    $jarat = $stmt->get_result()->fetch_assoc();

    if(!$jarat){
        die("Érvénytelen járat!");
    }
}

// Jegyfoglalás POST esetén
if($_SERVER["REQUEST_METHOD"] == "POST"){

    $jarat_id = $_POST['jarat_id'];
    $felhasznalo_id = $_SESSION['user_id'];

    // Alapár
    $ar = 3000;

    // Érvényesség (járat dátuma)
    $ervenyes = date("Y-m-d", strtotime($_POST['indulasi_ido']));

    // Ülőhely generálás
    $sor = chr(rand(65, 70));  // A-F
    $szek = rand(1, 20);
    $ulohely = $sor . $szek;

    // Jegy adatbázisba
    $stmt = $conn->prepare("
        INSERT INTO jegyek (felhasznalo_id, jarat_id, ar, ervenyes_datum, ulohely)
        VALUES (?, ?, ?, ?, ?)
    ");

    $stmt->bind_param("iiiss",
        $felhasznalo_id,
        $jarat_id,
        $ar,
        $ervenyes,
        $ulohely
    );

    if($stmt->execute()){
        $uzenet = "Sikeres jegyfoglalás! Ülőhely: $ulohely | Ár: {$ar} Ft";
    } else {
        $uzenet = "Hiba történt a foglalás során!";
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Jegyvásárlás</title>

    <link rel="stylesheet" href="oldal_style.css">
    <link rel="stylesheet" href="menu.css">
</head>
<body>

<?php include 'menu.php'; ?>

<div class="ticket-container">

    <h1>Jegyvásárlás</h1>

    <?php if($uzenet): ?>
        <p style="background:#e9f4ff; border-left:4px solid #0f4a6d; padding:12px;">
            <?= $uzenet ?>
        </p>
    <?php endif; ?>

    <?php if(isset($jarat)): ?>

        <div class="results-box">
            <h2>Kiválasztott járat:</h2>
            <p><strong>Járatszám:</strong> <?= $jarat['jarat_szam'] ?></p>
            <p><strong>Indulás:</strong> <?= $jarat['indulasi_allomas'] ?> – <?= $jarat['indulasi_ido'] ?></p>
            <p><strong>Érkezés:</strong> <?= $jarat['erkezesi_allomas'] ?> – <?= $jarat['erkezesi_ido'] ?></p>
        </div>

        <form method="POST">
            <input type="hidden" name="jarat_id" value="<?= $jarat['jarat_id'] ?>">
            <input type="hidden" name="indulasi_ido" value="<?= $jarat['indulasi_ido'] ?>">
            <button class="search-btn" style="margin-top:20px;">Jegy foglalása</button>
        </form>

    <?php else: ?>
        <p>Nincs kiválasztott járat.</p>
    <?php endif; ?>

</div>

</body>
</html>
